function [prc,chains] = schedule(prc,stop,verbose)
% 
% SCHEDULE  Schedule a process
%      
%             obj = schedule(obj,stop)       % stop time
%             obj = schedule(obj,{steps})
%             obj = schedule(obj)            % steps = 10
%
%          See also   DISCO, DPROC

   knd = kind(prc);
   dat = data(prc);

% check arguments

   if (~strcmp(knd,'process'))
      error('Arg1 must be of kind process!');
   end
   
   if (nargin <3) verbose = 0; end
   
   if (nargin < 2)
      steps = 10;
      stop = inf;
   else
      if (iscell(stop))
         steps = stop{1};
         stop = inf;
      else
         steps = inf;
      end
   end


% setup lists

   [m,n] = sizes(prc);
   n = zeros(m,1);          % number of columns (elements in a chain)
   time = zeros(m,1);       % last stop time of chain i
   threads = {};
   
% setup matrix of process elements (table) and initialize state

   [table,elist,keys] = element(prc);

% setup initial state and event dependencies, initialize sequences

   for (i=1:m)
      [obj,tstop] = run(table{i,1},0);
      state(i) = key(prc,name(obj));
      sequence{i} = {obj};      % sequences are sucessively constructed
      time(i) = tstop;
      tail(i) = 0;
      n(i) = 1;
      [x,y] = points(obj);
      critical{i,1} = {{[i i],[0 tstop],[0 y(length(y))]}};
      critical{i,2} = {name(obj)};
   end
   
% setup dependence matrix

   for (i=1:length(elist))
      keylist = depends(prc,elist{i});
      depend{i} = keylist;
   end

% start scheduling

   kk = 0;  tend = 0;
   while (kk < steps & tend <= stop)
      kk = kk+1;
      fprintf('Step %g: ',kk);
      showstate(prc,state,time);
      
      s = state;  t = time;  ta = tail;   % copy
      
      
         % first search for the earliest steps to perform      
         
      starting = inf;  % init
         
      for (i=1:length(elist))
         if ~contains(state,keys(i))
            [rdy,objidx] = ready(depend{i},state); 
            if rdy  % if an object is ready
               obj = elist{i};
               start = 0;
               for (j=1:length(objidx))
                  [ii,jj] = key(prc,objidx(j));
                  el = table{ii,jj};
                  start = max(start,time(ii));
               end
               
               starting = min(start,starting);
            end
         end
      end
      
         % now run all ready process steps at starting time      
      
      for (i=1:length(elist))
         if ~contains(state,keys(i))
            [rdy,objidx] = ready(depend{i},state); 
            
            if rdy  % if an object is ready
               obj = elist{i};
               [x,y] = points(obj);
               yhead = y(1);  ytail = y(length(y));
               
               if (verbose >= 1) 
                  fprintf(['   Depending on events: ',smartlook(getp(elist{i},'events')),'\n'])
               end
               
               start = 0;  newthreads = {}; namefrom = '';
               for (j=1:length(objidx))
                  [ii,jj] = key(prc,objidx(j));
                  el = table{ii,jj};
                  start = max(start,time(ii));
                  namefrom = name(el);
                  newthreads{j} = {ii,[time(ii) time(ii)],[tail(ii),yhead],namefrom};
                  if (verbose >= 1)
                     fprintf('      event %g: (at %g) ',j,time(ii));el; 
                  end
               end
               
               if (start == starting)
                  [obj,tstop] = run(obj,start);               
                  tend = max(tend,tstop);
                  if (verbose == 0)
                     fprintf(['%6g: ',info(obj),'\n'],start);
                  else
                     fprintf(['   Run (%g to %g): ',info(obj),'\n'],start,tstop);
                  end
               
                     % get key(k) and row index (ii)
                  
                  k = keys(i);
                  [ci,ans] = key(prc,k);
                  s(ci) = k;         % update state 
                  t(ci) = tstop;     % update time
                  n(ci) = n(ci)+1;   % increment number of chain items
                  ta(ci) = ytail;
         
                     % update threads
                  
                  crit = {};    maxx = -inf;
                  for (j=1:length(newthreads))
                     thread = newthreads{j};       
                     thread{1} = [thread{1} ci];
                     threadx = thread{2};
                  
                     if (max(threadx) >= maxx)   % find critical thread
                        crit = thread;
                        maxx = max(threadx);
                     end
                  
                     if (verbose >= 2)
                        fprintf(['      Thread ',thread{4},'(%g) -> ',name(obj),'(%g)\n'],threadx(1),threadx(2));
                     end
                     threads{length(threads)+1} = thread;
                  end
               
                     % update critical threads
                  
                  cidx = crit{1};         % chain indices from - to
                  cf = cidx(1);           % chain index from
               
                  threadlist = critical{cf,1};
                  threadlist{length(threadlist)+1} = crit;
                  critical{ci,1} = threadlist;
               
                  namelist = critical{cf,2};   % name list
                  namelist{length(namelist)+1} = name(obj);
                  critical{ci,2} = namelist;
               
                     % add to sequence
               
                  seq = sequence{ci};
                  seq{n(ci)} = obj;
                  sequence{ci} = seq;
               end % if start
            end % if rdy
         end
      end
      state = s;  % state transition
      time = t;   % time transition
      tail = ta;  % tail transition
   end
   %fprintf('Stop\n');
   
   for (i=1:m)
      seqargs{i} = setp(element(prc,i),'list',sequence{i});
   end
   
   text = getp(prc,'text');
   prc = process(dproc(name(prc)),seqargs{:});
   prc = setp(prc,'threads',threads,'text',text,'critical',critical);

% eof

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function keys = depends(prc,obj)  % get keys of dependend objects
   keys = [];
   events = getp(obj,'events');

   for (i=1:length(events))
      evi = events{i};
      kvec = [];
      for (j=1:length(evi))
         k = key(prc,evi{j});      
         if isempty(k)
            error(['could not find object for event ''',evi{j},''' of <',info(obj),'>']);
         end
         kvec(j) = k;
      end
      keys{i} = kvec;
   end
return

function [ok,objidx] = ready(keys,state)
   objidx = [];
   if (~isempty(keys))
      for (i=1:length(keys))
         kvec = keys{i};
         ok = 1;
         for (j=1:length(kvec))
            idx = find(kvec(j)==state);
            if (isempty(idx))
               ok = 0;
            end
         end
         if (ok)   
            objidx = kvec;   % return indices of depending objects
            return;
         end 
      end
   end
   ok = 0;
return

function ok = contains(vector,element)
   ok = 0;
   if (isempty(vector) | isempty(element)) return; end
   for (i=1:length(element))
      idx = find(vector==element(i));
      if (isempty(idx)) return; end;
   end
   ok = 1;
return

function showstate(prc,state,time)
   text = 'State:';
   for (i=1:length(state))
      el = element(prc,state(i));
      if isa(el,'dproc')
         text = [text,' ',name(el)];
         if (nargin >= 3)
            text = [text,sprintf('(%g)',time(i))];
         end
      else
         text = [text,' []'];
      end
   end
   fprintf([text,'\n']);
return

function idx = chainidx(prc,k)
   [idx,j] = key(prc,k);
   return
   
function sm = smartlook(events)
   sm = '';
   for (i=1:length(events))
      evi = events{i};
      for j=1:length(evi)
         str = evi{j};  n = length(str);
         sm = [sm,str,' '];
      end
      if (i < length(events)) sm = [sm,';']; end
   end
   return        
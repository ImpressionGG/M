function out = version(obj)
%
% VERSION   Get version of a CORE object class
%
%              vs = version(core);   % get version string
%              version(core);        % type also release notes / known bugs
%
%           See also: CORE
%
%--------------------------------------------------------------------------
%
% Release Notes Core/V4A
% ===========================
%
% - configure as an independent toolbox
% - edit version in info menu added
% - move through menu tree functionality added to core/mitem 
% - Backup Core.V4a.Bak5, Toy.V4a.Bak5
% 
%
% Known Bugs & ToDo's
% ===================
%
% - no known bugs
%
   path = upper(which('core/version'));
   idx = max(findstr(path,'\@CORE\VERSION.M'));
   vers = path(idx-3:idx-1);
   
   if (nargout == 0)
      help core/version
      line = '--------------------';
      fprintf([line,line,line,line,'\n']);
      fprintf(['CHAMELEON Toolbox - Version: ',vers,'\n']);
      fprintf([line,line,line,line,'\n']);
   else
      out = vers;
   end

%    if (nargout == 0)
%       version(core)
%    else
%       out = version(core);
%    end
   return
end   
   
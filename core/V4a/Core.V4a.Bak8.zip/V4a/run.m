%run

echo on
H = toy(1:2)
u = H(1)
d = H(2)
r = [H(1)+H(2)]/sqrt(2)
l = [H(1)-H(2)]/sqrt(2)

echo off

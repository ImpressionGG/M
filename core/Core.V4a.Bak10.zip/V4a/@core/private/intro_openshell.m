% intro_openshell
figure(0815);                 % make 0815 figure our current figure
echo on;
%
% OPEN A 'PLAY SHELL'
% ===================
%
% Let's invoke some commands which open a 'play shell' (a simple shell to
% play around).
%
   core play                  % open a shell to play arround
%
[];


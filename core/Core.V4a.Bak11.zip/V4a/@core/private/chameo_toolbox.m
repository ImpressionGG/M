% chameo_toolbox
echo on;
%
% LAUNCHING CHAMEO TOOLBOX SHELL
% ==============================
%
% In order to launch Chameo Toolbox shell just enter:
%
;; chameo toolbox
%
% This command launches a shell for a CHAMEO object which offers a couple
% of tool commands, such as sniffing a file or making a CHAMEO m-file out
% of a log file. 
%
[];
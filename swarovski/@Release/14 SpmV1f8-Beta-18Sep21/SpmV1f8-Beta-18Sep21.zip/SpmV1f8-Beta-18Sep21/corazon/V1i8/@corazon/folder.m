%
% FOLDER   Get path to parent folder of class directory from a CORAZON
%          class or CORAZON derived class
%
%             path = folder(corazon);
%
%             rapid(corazon,'espresso');
%             path = folder(espresso);
%
%          Copyright(c): Bluenetics 2021
%
%          See also: CORAZON
%

%
% PACK   Pack CORAZON object into a bag:
%
%           bag = pack(o)              % pack object into a bag
%
%        Copyright(c): Bluenetics 2020 
%
%        See also: CORAZON, UNPACK, CONSTRUCT
%

%
% GRID   Switch grid on or off, depending on option 'plot.grid'
%
%             grid(o)                  % set grid on/off (depend on option)
%             onoff = grid(o)          % return grid on/off option
%
%        Copyright(c): Bluenetics 2020 
%
%        See also: CORAZON, PLOT, DARK, DONE
%

%
% PACK   Pack CORAZITA object into a bag:
%
%           bag = pack(o)              % pack CORAZITA object into a bag
%
%        Copyright(c): Bluenetics 2020 
%
%        See also: CORAZITA
%

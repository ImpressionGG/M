function shg(o)
%
% SHG   Show graphics of object's figure
%
%          shg(o);                     % show graphics
%          figure(figure(o));          % same as above
%
%    See also: CORAZON, CLS
%    Copyright (c): Bluenetics 2020 
%
   figure(figure(o));
end   

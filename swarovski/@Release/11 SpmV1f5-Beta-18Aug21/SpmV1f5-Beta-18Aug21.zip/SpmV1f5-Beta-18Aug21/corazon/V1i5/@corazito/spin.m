%
% SPIN   Spin View   
%
%    Copyright(c): Bluenetics 2020 
%
%    See also: CORAZITO
%

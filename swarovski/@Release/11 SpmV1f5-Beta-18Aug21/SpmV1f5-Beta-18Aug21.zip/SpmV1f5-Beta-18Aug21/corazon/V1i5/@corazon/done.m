%
% DONE   Done with diagram - calls grid(o) method and calls dark(o,'Axes')
%        to refresh dark mode if selected
%
%           done(o)                  % set grid on/off (depend on option)
%
%        Copyright(c): Bluenetics 2020 
%
%        See also: CORAZON, PLOT, DARK, GRID, CLS
%

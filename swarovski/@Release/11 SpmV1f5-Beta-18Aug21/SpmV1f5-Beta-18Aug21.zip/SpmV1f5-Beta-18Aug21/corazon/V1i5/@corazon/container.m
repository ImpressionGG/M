%
% CONTAINER   create a container, or return status whether object is a
%             container object?
%
%                o = container(corazon,{o1,o2,...});   % create a container  
%                ok = container(o)        % is object a container object?
%
%             Copyright(c): Bluenetics 2020 
%
%             See also: CORAZON
%

%
% USER   Get user information
%
%           name = user(o,'name')      % user name
%           home = user(o,'home')      % user home directory
%           dir = user(o,'dir')        % user working directory
%
%    Copyright(c): Bluenetics 2020 
%
%    See also: CORAZON
%

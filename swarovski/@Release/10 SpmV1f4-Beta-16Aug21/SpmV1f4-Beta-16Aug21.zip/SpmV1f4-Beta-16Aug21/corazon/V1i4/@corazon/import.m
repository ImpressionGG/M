%
% IMPORT   Import object(s) from file
%
%             list = import(o,'ReadText','.txt')
%
%          Copyright(c): Bluenetics 2020 
%
%          See also: CORAZON, EXPORT, READ
%

%
% MAKE   Make toolbox version based on source version
%
%           make(corazon,'V1i2')
%
%        Note: make an obfuscated toolbox based on current (active)
%        toolbox. This means that path settings must be on current CORAZON
%        toolbox
%
%        Copyright(c): Bluenetics 2021
%
%        See also: CORAZON, CORAZITO, CORAZITA
%

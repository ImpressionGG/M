%
% DIGITS   Return maximum digit number of a corinthian object
%
%             n = digits(o)
%
%          Copyright(c): Bluenetics 2020
%
%          See also: CORINTH, ORDER, SIZE
%

%
% VERSION   CORLEON toolbox version / release notes
%
%    Print CORLEON release notes / bug list or get CORLEON version
%
%       vs = version(corleon);        % get CORLEON version string
%       version(corleon);             % type release notes / known bugs
%
%    Copyright(c): Bluenetics 2020 
%
%    See also: CORLEON
%
%--------------------------------------------------------------------------
%
%

%
% FIGURE   Get/Set figure handle of an object
%
%             o = figure(o,fig)        % set object's figure handle 
%             fig = figure(o);         % get object's figure handle
%
%          Copyright(c): Bluenetics 2020 
%
%          See also: CORAZITA, WORK
%

%
% SAVE   Save a bag of properties to .MAT file
%
%           o = save(corazita,bag)
%           o = save(corazita,pack(o))
%
%        Copyright(c): Bluenetics 2020 
%
%        See also: CORAZITA, LOAD, DIRECTORY
%

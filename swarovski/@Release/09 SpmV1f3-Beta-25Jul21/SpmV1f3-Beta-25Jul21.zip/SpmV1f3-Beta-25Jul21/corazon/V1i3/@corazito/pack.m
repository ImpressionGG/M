%
% PACK   Pack CORAZITO object into a bag:
%
%           bag = pack(o)              % pack CORAZITO object into a bag
%
%        Copyright(c): Bluenetics 2020 
%
%        See also: CORAZITO
%

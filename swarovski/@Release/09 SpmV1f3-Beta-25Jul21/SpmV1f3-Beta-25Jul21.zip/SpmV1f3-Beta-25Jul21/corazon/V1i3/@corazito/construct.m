%
% CONSTRUCT   Construct an object from bag
%
%                o = construct(corazito,'corazon')
%                o = construct(corazito,bag)
%
%             Copyright(c): Bluenetics 2020 
%
%             See also: CORAZITO, PACK
%

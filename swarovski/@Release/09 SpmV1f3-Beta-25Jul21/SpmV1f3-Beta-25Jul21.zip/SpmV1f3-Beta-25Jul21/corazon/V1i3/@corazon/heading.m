%
% HEADING  Draw figure heading
%
%             hdl = heading(o,text)    % draw figure heading
%             hdl = heading(o)         % use title as figure heading
%
%          Copyright(c): Bluenetics 2020 
%
%          See also: CORAZON, PLOT
%

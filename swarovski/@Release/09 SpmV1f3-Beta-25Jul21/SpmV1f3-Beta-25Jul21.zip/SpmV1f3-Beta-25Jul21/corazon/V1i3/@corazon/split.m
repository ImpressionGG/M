%
% SPLIT   Split package name into parts
%
%            [package,typ,name,run,mach] = split(o,title)
%            [package,typ,name,run,mach] = split(o,o.par.title)
%            [package,typ,name,run,mach] = split(o)    % same as above
%
%            split(o,title)            % show splitted info
%            split(o)                  % show splitted info
%
%         See also: CORAZON
%

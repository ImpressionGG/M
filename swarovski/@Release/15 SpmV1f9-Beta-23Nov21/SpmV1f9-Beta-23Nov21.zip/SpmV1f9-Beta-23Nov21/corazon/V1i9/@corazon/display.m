%
% DISPLAY   Display a CORAZON object
%
%              display(o)              % display a corazon object
%              display(corazon,oo)     % display other class object
%
%           Copyright(c): Bluenetics 2020 
%
%           See also: CORAZON
%

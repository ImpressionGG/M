%
% TITLE  Get object's title
%
%           title(o)                   % set title in figure window
%           [txt,raw] = title(o)       % get title text
%
%        Underscores are provided with escape characters ('\') for
%        output arg 'txt', while 'raw' is the output text in raw form.
%
%        See also: CUT, CUL
%

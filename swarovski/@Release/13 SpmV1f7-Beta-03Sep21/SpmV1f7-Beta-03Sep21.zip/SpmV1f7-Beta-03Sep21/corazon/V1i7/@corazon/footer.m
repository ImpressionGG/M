%
% FOOTER  Draw figure footer
%
%             hdl = footer(o,text)    % draw figure footer
%
%          Copyright(c): Bluenetics 2021
%
%          See also: CORAZON, PLOT, HEADING
%

% 
% SHELL  Open new figure and setup menu for a CORAZITA object
%      
%           o = corazita     % create a CORAZITA object
%           shell(o)         % open a tiny CORAZITA shell
%
%        Copyright(c): Bluenetics 2020 
%
%        See also: CORAZITA, MENU, SHO, CUO
%

%
% DIRECTORY   Persistent storage of current save/load directory
%
%           directory(corazito,path)   % store persistent directory path
%           path = directory(corazito) % recall persistent directory path
%
%        Copyright(c): Bluenetics 2020 
%
%        See also: CORAZITO, FSELECT, LOAD, SAVE
%

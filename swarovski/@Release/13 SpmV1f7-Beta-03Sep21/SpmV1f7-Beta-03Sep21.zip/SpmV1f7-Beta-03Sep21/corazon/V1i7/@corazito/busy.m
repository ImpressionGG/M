%
% BUSY   Change mouse pointer to 'busy symbol' and set busy message in
%        figure bar.
%
%           busy(o)                    % set busy state
%           busy(o,'plotting ...')     % set busy state and set message
%
%        Copyright(c): Bluenetics 2020 
%
%        See also: CORAZITO, READY
%

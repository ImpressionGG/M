%
% SIMPLE   Simple plugin
%
%             simple(sho)              % plugin registration
%
%             oo = simple(o,func)      % call local simple function
%
%          Read Driver for Simple & Plain Objects
%
%             oo = simple(o,'New');
%             oo = simple(o,'Simu');
%             oo = simple(o,'Plot');
%
%          See also: CORAZON, PLUGIN, SAMPLE
%

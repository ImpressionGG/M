%
% READY   Change mouse pointer to 'ready symbol' and restore object's 
%         title in figure bar.
%
%            ready(o)                  % set ready state
%
%        Copyright(c): Bluenetics 2020 
%
%        See also: CARABUL, BUSY
%

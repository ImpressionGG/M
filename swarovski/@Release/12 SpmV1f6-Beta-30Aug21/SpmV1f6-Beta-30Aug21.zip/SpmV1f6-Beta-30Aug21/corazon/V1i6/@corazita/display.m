%
% DISPLAY   Display a CORAZITA object
%
%              display(o)
%
%           Copyright(c): Bluenetics 2020 
%
%           See also: CORAZITA
%

%
% EXPORT   Export an ESPRESSO object to a log file.
%
%             oo = export(o,'WriteStuffTxt','.txt') % export object to file
%
%          Copyright(c): Bluenetics 2020 
%
%          See also: CORAZON, WRITE, IMPORT
%

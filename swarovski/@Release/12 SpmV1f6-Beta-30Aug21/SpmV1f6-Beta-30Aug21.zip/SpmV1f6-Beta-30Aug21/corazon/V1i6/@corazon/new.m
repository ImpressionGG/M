%
% NEW   Create new CORAZON object.
%
%          oo = new(o,'Menu')          % setup menu
%
%       New Corazon stuff
%
%          oo = new(o,'Weird')         % oo.type = 'weird'
%          oo = new(o,'Ball')          % oo.type = 'ball'
%          oo = new(o,'Cube')          % oo.type = 'cube'
%          oo = new(o,'Txy')           % oo.type = 'txy'
%
%       Copyright(c): Bluenetics 2020 
%
%       See also: CORAZON
%
